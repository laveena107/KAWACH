package com.example.kawach;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class womenhealth extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_womenhealth);
        iv=findViewById(R.id.imageView11);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it= new Intent(getApplicationContext(),kawach.class);
                startActivity(it);
            }
        });
        bottomNavigationView= findViewById(R.id.bottom_navigator);

        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.report:
                        startActivity(new Intent(getApplicationContext(), report.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.help:
                        startActivity(new Intent(getApplicationContext(), help.class));
                        overridePendingTransition(0,0);
                        return true;


                    case R.id.home:

                        startActivity(new Intent(getApplicationContext(), home.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext(),profile.class));
                        overridePendingTransition(0,0);
                        return true;
                }


                return false;
            }
        });
    }
}